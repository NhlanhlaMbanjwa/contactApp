﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactApplications.Models
{
    public class RegLogModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class UserIDModel
    {
        public int UserID { get; set; }
    }

    public class ContactIDModel
    {
        public int ContactID { get; set; }
    }

    public class ContactPhoneModel
    {
        public string  PhoneNumber { get; set; }
    }
}