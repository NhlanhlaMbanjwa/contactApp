﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ContactApplications.Models
{
    public class ContactModel
    
    {
        [Key]
        public int ContactID { get; set; }
        //[Required]
        //[MaxLength(10)]
        [Display(Name = "Phone number")]
        public string PhoneNumber { get; set; }

        //[Required]
        [Display(Name = "Email address")]
        public string EmailAddress { get; set; }

        //Required]
        [Display(Name = "Birth date")]
        public DateTime Birthdate { get; set; }

        //[Required]
        public string Notes { get; set; }
        
        public bool Favourite { get; set; }
        public int UserID { get; set; }

    }
}