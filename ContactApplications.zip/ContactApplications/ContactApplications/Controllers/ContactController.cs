﻿using ContactApplications.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ContactApplications.Controllers
{
    public class ContactController : Controller
    {
        //
        // GET: /Contact/
        public ActionResult Index()
        {
            try
            {
                int userID = Convert.ToInt16(Session["UserID"]);
                IEnumerable<ContactModel> contacts = ContactApplications.Repo.Imp.Implementation.contactList(userID);

                return View(contacts);
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Favorite()
        {
            try
            {
                IEnumerable<ContactModel> contacts = ContactApplications.Repo.Imp.Implementation.FavoriteContactList();

                return View(contacts);
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Search(ContactModel contactModel)
        {
            try
            {
                
                if (ModelState.IsValid)
                {
                    ContactModel contact = ContactApplications.Repo.Imp.Implementation.SearchContact(contactModel);
                    return View(contact);
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Contact/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Contact/Create
        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Contact/Create
        [HttpPost]
        public ActionResult Create(ContactModel contactModel)
        {
            try
            {
                contactModel.UserID = Convert.ToInt16(Session["UserID"]);

                if (ModelState.IsValid)
                {
                    if (ContactApplications.Repo.Imp.Implementation.AddContact(contactModel))
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Contact/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                ContactModel contact = ContactApplications.Repo.Imp.Implementation.Editcontact(id);

                return View(contact);

            }
            catch
            {
                return View();
            }

        }

        //
        // POST: /Contact/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, ContactModel contactModel)
        {
            try
            {
                contactModel.ContactID = id;
                if (ContactApplications.Repo.Imp.Implementation.Editcontact(contactModel))
                {
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Contact/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                ContactModel contact = ContactApplications.Repo.Imp.Implementation.Editcontact(id);

                return View(contact);

            }
            catch
            {
                return View();
            }
        }

        //
        // POST: /Contact/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                if (ContactApplications.Repo.Imp.Implementation.DeleteContact(id))
                {
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }
    }
}
