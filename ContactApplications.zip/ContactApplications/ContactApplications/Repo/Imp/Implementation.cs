﻿using ContactApplications.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Dapper;

namespace ContactApplications.Repo.Imp
{
    public class Implementation
    {

        private static string ReturnConnectionString()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["DBContactManagementSystem"].ConnectionString;
        }
        public static bool RegisterUser(RegisterViewModel register)
        {
            RegLogModel rModel = new RegLogModel()
                {
                    UserName = register.UserName,
                    Password = register.Password
                };

            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                var result = connection.Query<RegLogModel>("SP_RegisterUsers", rModel, commandType: CommandType.StoredProcedure);
                return true;
            }
        }

        public static UserIDModel LoginUser(LoginViewModel register)
        {
            RegLogModel lModel = new RegLogModel()
            {
                UserName = register.UserName,
                Password = register.Password
            };

            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                UserIDModel result = connection.Query<UserIDModel>("SP_Login", lModel, commandType: CommandType.StoredProcedure).FirstOrDefault();

                return result;
              
            }
        }

        public static IEnumerable<ContactModel> contactList(int UserID)
        {
            UserIDModel userIDModel = new UserIDModel()
            {
                UserID = UserID
            };
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                var result = connection.Query<ContactModel>("SP_ContactList", userIDModel, commandType: CommandType.StoredProcedure);
                return result;
            }
        }

        public static IEnumerable<ContactModel> FavoriteContactList()
        {    
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                var result = connection.Query<ContactModel>("SP_FavoriteContactList", null, commandType: CommandType.StoredProcedure);
                return result;
            }
        }

        public static ContactModel Editcontact(int id)
        {
            ContactIDModel contactIDModel = new ContactIDModel()
            {
                ContactID = id
            };
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                ContactModel result = (ContactModel)connection.Query<ContactModel>("SP_EditContact", contactIDModel, commandType: CommandType.StoredProcedure).FirstOrDefault();
                return result;
            }
        }

        public static bool DeleteContact(int id)
        {
            ContactIDModel contactIDModel = new ContactIDModel()
            {
                ContactID = id
            };
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                ContactModel result = (ContactModel)connection.Query<ContactModel>("SP_DeleteContact", contactIDModel, commandType: CommandType.StoredProcedure).FirstOrDefault();
                return true;
            }
        }

        public static bool Editcontact(ContactModel contactModel)
        {
            
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                var result = connection.Query<ContactModel>("SP_UpdateContact", contactModel, commandType: CommandType.StoredProcedure);
                return true;
            }
        }


        public static ContactModel SearchContact(ContactModel contactModel)
        {
            ContactPhoneModel contactPhoneModel = new ContactPhoneModel()
            {
                PhoneNumber = contactModel.PhoneNumber
            };
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                ContactModel result = (ContactModel)connection.Query<ContactModel>("SP_SearchContact", contactPhoneModel, commandType: CommandType.StoredProcedure).FirstOrDefault();
                return result;
            }
        }

        public  static bool AddContact(ContactModel contactModel)
        {
            using (var connection = new SqlConnection(ReturnConnectionString()))
            {
                var result = connection.Query<ContactModel>("SP_InsertContact", contactModel, commandType: CommandType.StoredProcedure);
                return true;
            }
        }
    }

   
  
}